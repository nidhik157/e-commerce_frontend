import React from 'react'

export const BlogCard = () => {
  return (
    <div className='col-3'>
        <div className='blog-card'>
            
        </div>
    </div>
  )
}
